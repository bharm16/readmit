# Rerun retained connected evidence

Verification is offline: readmit report connected verify PACKET
It reads only the retained lifecycles; no server, file export, database or
credential is contacted, and no historical path is resolved.

Keep this packet immutable. Each lifecycle's plan is under SECTION/plan and
its original inputs under SECTION/plan/phases. A new execution needs the
original authored test, a newly prepared plan and a runtime configuration
naming an authorized nonproduction environment, its grants and credentials.
None of those are reconstructed from this packet: historical targets, grants
and bound server identities are evidence, never runnable authority.

    readmit connected prepare INPUT_DIRECTORY PLAN --seed SEED --base-time TIME
    readmit test PLAN --connected-config CONFIG --instance NEW_INSTANCE
    readmit test PLAN --connected-config CONFIG --instance NEW_INSTANCE --send --output NEW_RESULT

The first test command prepares without effects. The second explicitly
authorizes execution. Exit 0 is pass, 1 assertion failure, 2 unresolved.
Retain the new result beside this one; never overwrite either.

A reproduction claim needs two retained actual executions of the same plan
against the same declared target (readmit report connected assemble --replay).
A missing baseline is never recreated, a lost response is never resent, and
an uncertain effect must be reconciled at the target before any new run.
